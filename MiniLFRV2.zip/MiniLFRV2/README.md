# MiniLFRV2
The V2 revision of mini linefollow robot